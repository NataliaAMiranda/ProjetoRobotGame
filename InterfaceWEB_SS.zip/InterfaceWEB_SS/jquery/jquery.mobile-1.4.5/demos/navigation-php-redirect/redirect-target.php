<?php
	sleep(2);
?>
<!DOCTYPE html>
<html>
<head>

  <title>Redirect Target</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="http://code.jquery.com/mobile/latest/jquery.mobile-1.4.5.min.css">
  <script src="http://code.jquery.com/jquery-1.8.3.js"></script>
  <script src="http://code.jquery.com/mobile/latest/jquery.mobile.js"></script>

</head>
<body>
<div data-role="page">
	<div data-role="header">
		<h1>Redirect Target</h1>
	</div>
	<div role="main" class="ui-content">
		<p>Content</p>
		<tt>
		</tt>
	</div>

</div>
</body>
</html>
