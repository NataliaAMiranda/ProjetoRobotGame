function envia(dir,steps) {

  enviaJSON = dir;
  enviaJSON1 = steps;
  //alert(enviaJSON);
  //alert(enviaJSON1);

  var info = new Object();
  info['dir'] = dir;
  info['steps'] = parseInt(steps);

	

  var info_JSON = JSON.stringify(info);

  $.ajax({
    type       : "PUT",
    url        : "http://192.168.0.3:5000/atualiza",
    crossDomain: true,
    data       : info_JSON,
    async      : false,
    dataType   : 'json',
    contentType: 'application/json; charset=utf-8',
    complete: function(){
        $('#loading_image').hide();
      },
      success    : function(response) {

        if(response['ok'] != (-1)) {
          //alert('ok');
        }
        else {
          alert('Erro.');
        }

      },
      error      : function() {
        alert('Falha na comunicação com o servidor! \n Verifique sua conexão.');
      }
    });
  }
